class FollowerModel {
	public userId: number;
    public vacationId: number;
}

export default FollowerModel;
