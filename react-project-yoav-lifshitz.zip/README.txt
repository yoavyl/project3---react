The project was uploaded to Heroku:
https://observacation-website-by-yoav.herokuapp.com/

You can test it using
• username: testing123 (user) or username: admin123 (admin)
• password: Aa1!Aa1! (for both)
• or registering a new user yourself

If admin adds / deletes / updates a vacation, users see the change in real time.
see project's GitHub page:
https://github.com/yoavyl/project4---react